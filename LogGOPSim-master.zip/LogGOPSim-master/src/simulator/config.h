#ifndef __CONFIG_H__
#define __CONFIG_H__

#define HAS_GEM5 0

//#HASCALCGEM5#
//#LIBGEM5DIR#
//#GEM5EXECUTABLE#


#endif /* __CONFIG_H__ */

