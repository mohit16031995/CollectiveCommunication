#ifndef __LOGGOPSIM_H_
#define  __LOGGOPSIM_H_

typedef uint64_t btime_t;


#endif
